#!/usr/bin/env python
# coding: utf-8

# In[3]:


# import os 

# model_file_path = os.path.join ("C:\Users\hp\Downloads\Credit card script\project","C:\Users\hp\Downloads\Credit card script\project\credit_card_fraud_model8 (1).pkl")
# json_file_path  = os.path.join ("C:\Users\hp\Downloads\Credit card script\project","C:\Users\hp\Downloads\Credit card script\project\prj_data_yash.json")
# PORT_NUMBER=9005
import os

model_file_path = os.path.join(r"C:\Users\hp\Downloads\Credit card script\project", r"credit_card_fraud_model8 (1).pkl")
json_file_path  = os.path.join(r"C:\Users\hp\Downloads\Credit card script\project", r"prj_data_yash.json")
PORT_NUMBER = 9005

print(model_file_path)
print(json_file_path)




#{"columns": ["Time","V1","V2","V3","V4","V5","V6","V7","V8","V9","V10","V11","V12","V13","V14","V15","V16","V17","V18","V19","V20","V21","V22","V23","V24","V25","V26","V27","V28","Amount" ]}


# In[ ]:




