#!/usr/bin/env python
# coding: utf-8

# In[2]:


from flask import Flask,jsonify,render_template,request
import config_yash
import numpy as np
#from flask_mysqldb import MySQL
import json
import pickle

app = Flask(__name__)

#### MYSQL CONFIGURATION ####
# app.config ["MYSQL_HOST"]= "localhost"
# app.config ["MYSQL_USER"] ="root"
# app.config ["MYSQL_PASSWORD"] = "akash9595"
# app.config ["MYSQL_DB"]  = "iris"
# mysql = MySQL(app)

with open (config_yash.model_file_path,"rb") as f:
    model=pickle.load(f)


with open (config_yash.json_file_path,"r") as f:
    prjdata=json.load(f)

@app.route("/")
def home_api():
    return render_template("index.html")

@app.route("/predict",methods=["GET","POST"])
def get_prediction():
    data = request.form
    array=np.zeros(30)
    array[0]= eval(data["Time"])
    a=array[0]
    array[1] = eval(data["V1"])
    b=array[1]
    array[2] = eval(data["V2"])
    c=array[2]
    array[3]= eval(data["V3"])
    d=array[3]
    array[4]= eval(data["V4"])
    a=array[4]
    array[5] = eval(data["V5"])
    b=array[5]
    array[6] = eval(data["V6"])
    c=array[6]
    array[7]= eval(data["V7"])
    d=array[7]
    array[8]= eval(data["V8"])
    a=array[8]
    array[9] = eval(data["V9"])
    b=array[9]
    array[10] = eval(data["V10"])
    c=array[10]
    array[11]= eval(data["V11"])
    d=array[11]
    array[12]= eval(data["V12"])
    a=array[12]
    array[13] = eval(data["V13"])
    b=array[13]
    array[14] = eval(data["V14"])
    c=array[14]
    array[15]= eval(data["V15"])
    d=array[15]
    array[16]= eval(data["V16"])
    a=array[16]
    array[17] = eval(data["V17"])
    b=array[17]
    array[18] = eval(data["V18"])
    c=array[18]
    array[19]= eval(data["V19"])
    d=array[19]
    array[20]= eval(data["V20"])
    a=array[20]
    array[21] = eval(data["V21"])
    b=array[21]
    array[22] = eval(data["V22"])
    c=array[22]
    array[23]= eval(data["V23"])
    d=array[23]
    array[24]= eval(data["V24"])
    a=array[24]
    array[25] = eval(data["V25"])
    b=array[25]
    array[26] = eval(data["V26"])
    c=array[26]
    array[27]= eval(data["V27"])
    d=array[27]
    array[28]= eval(data["V28"])
    a=array[28]
    array[29] = eval(data["V29"])
    b=array[29]
    array[30] = eval(data["Amount"])
    c=array[30]
    z=model.predict([array])
    
    

#     cursor = mysql.connection.cursor()
#     query = "CREATE TABLE IF NOT EXISTS credit_table (SepalLengthCm VARCHAR(20),SepalWidthCm VARCHAR(20),PetalLengthCm VARCHAR(20),PetalWidthCm VARCHAR(20),PREDICT VARCHAR(20))"
#     cursor.execute(query)
#     cursor.execute("INSERT INTO iris_table (SepalLengthCm,SepalWidthCm,PetalLengthCm,PetalWidthCm,PREDICT) VALUES (%s,%s,%s,%s,%s)",(a,b,c,d,z))
#     mysql.connection.commit()
#     cursor.close()

    return render_template("index1.html",z=z)
    # return 


if __name__ == "__main__":
    app.run(host="0.0.0.0",port=config_yash.PORT_NUMBER)


# In[ ]:





# In[ ]:




